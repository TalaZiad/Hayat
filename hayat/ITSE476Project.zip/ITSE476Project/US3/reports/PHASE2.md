# Free/Libre software development phase 2 project report

Group Members:

| Name                         | ID       |
|------------------------------|----------|
| Abbas Ahmed Ebrahim          | 20176752 |
| Waleed Tawfeeq Mohamed       | 20175132 |
| Alaa Nagib Ghaleb            | 20165031 |
| Abdelrahman Khaled Abdelhadi | 20176022 |
| Ahmed Adel Ali               | 20177156 |
| Salman Khaled Abdelhadi      | 20176030 |


## Abbas's Experience
I take the responsibility of Managing pull requests and everybody contributions to make sure that we finish all our issues and close all of our pull requests and keep our repository away from merge conflicts as much as possibly by applying our police to assign team members to specific distinctive tasks as much as possible. In addition, I try to provide feedback to my teams actions when needed.

I think my experience was like linus torvalds (the creator of GNU/Linux kernel) where he do merge requests more than development and that's because I have wonderful team and above all of that I this experience shaped my communication skills and my expertise in free/libre software development and version control.


## Waleed's Experience
Before using GitHub, we face many issues related to how we can manage our changes and updates of our project. But now by using GitHub, we can easily access the latest files. I learned lots of things from GitHub. Now I can create new branches which allow me to develop features, fix bugs, or safely experiment with new ideas in a contained area of our repository.  Also, I can merge my work with the main repository by sending pull requests.

In the end, I believe that using GitHub will facilitate the development process of the projects for both individuals and organizations.


## Alaa's Experience



 
## Abdelrahman's Experience




## Ahmed's Experience
I found GitHub is very useful for learning about free and open-source software. I can now easily make contributions to projects online. Also, GitHub is very useful for team members of a programmers to upload their code and do modifications. It definitely is a great way to work on. The first time it was a bit hiatus, but over time it got easier. Moreover, Git requires knowledge of Command Line/Terminal or else the experience will be more difficult. Github was difficult at the start but it got easy.

 

## Salman's Experience

