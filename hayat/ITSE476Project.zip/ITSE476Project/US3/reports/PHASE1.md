# Free/Libre software development phase 1 project report

Group Members:

| Name                         | ID       |
|------------------------------|----------|
| Abbas Ahmed Ebrahim          | 20176752 |
| Waleed Tawfeeq Mohamed       | 20175132 |
| Alaa Nagib Ghaleb            | 20165031 |
| Abdelrahman Khaled Abdelhadi | 20176022 |
| Ahmed Adel Ali               | 20177156 |
| Salman Khaled Abdelhadi      | 20176030 |


## But First, Look Around: List all project and their links 

Our open-source project has similar projects which we can refer too. However, many of the systems that we look up are not free and open source, so we can’t join the existing projects. Thus, we must develop our project from the start and make it a free and open project for the public. Each project has certain functions that will be implemented in the US3 project. The new people that may be involved in the group can refer to the other project for reference and get a brief idea of the project goals. 

 

1. UoB Library System. Link: <http://library.uob.edu.bh/en/>

	This system has various services that will be provided in the US3 system, such as books borrowing, returning, searching and printing documents these tasks are for students. The other tasks are adding books, remove books, confirm book returns, and edit books. 

2. SIS UoB. Link: <https://sis.uob.edu.bh/uob_sis_prod/>

	The SIS UoB system offers a service that the US3 project will have which is as receiving reports like the certificates. Also, the system has the support function which students use to contact with the registration if any issue happens to students or any inquiries, this service will be offered in the US3 project. 

3. Bahrain eGoverment. [Link](https://services.bahrain.bh/wps/portal/!ut/p/a1/jY_NUoMwFEafxm1y5afEZQAFShE7iC1sOpGGlgqEoYj49g0s7Erau_ruzPluTnCKtzitWV8cWFeImpXjni52hDjWo0KUJfghAKXxmi5XVHGIKoFEAjpRLNeXQKhqOlDNX5tx6KoQwn19y6GuZqwAQCMKeLbp2sZTAOAt7uvDP0Nvvh_xGm9wOmFzv5iAOc0JmPFIpKhxNSGeZUkTI3jz4AXAUXA03jixng3ozNu-5B0q6qz83nPUsO64K-pc4OQB4tA0hfiKOtHyj4L_oOHYVeVYzkSFis8K5SzjZ9SIthuPVGLPcdJLEicmToP3QxzJaF2j_Rc3tySbKo63g3fSm_5Vf85_Lztehh4!/#Z7_88GC1282J8ICC0AA7MPI0F00G2 ):

	The following website offers a function that US3 will have which is buying books for registered courses. There is no need to visit this website to buy a book task, as it will be included in the US3 project.
	
4. UoB Mobile App. 

	Link iOS: <https://apps.apple.com/bh/app/uob/id1097814985>
	Link Android: <https://play.google.com/store/apps/details?id=com.uob.uobapp631612&hl=en&gl=US>

	The UoB app has receiving certificate’s function which is included in the US3 project. Also, calendar function but the US3 project will have more capabilities such as viewing events that the students registered to in calendar. 

5. moodle. Link: <https://moodle.org/>

	moodle free and open-source software has several functionalities that are like the US3 project. For example, the administrator can set up the required resources for courses such as books. Also, the students can check the calendar of events which is also included in the US3 project. Moreover, the administrator can add events, remove events, update events, and view events. The events can also be categorized. 


	The following table summarizes the US3 functionalities in which module they are, and which existing systems have similar tasks: 
	
	| US3 Functionality            | Existing System            |
	|:----------------------------:|:--------------------------:|
	| ***Library Module***         |                            |
	|                              |                            |
	| Select Book                  | UoB Library System         |
	| Search Book                  | UoB Library System         |
	| Borrow Book                  | UoB Library System         |
	| Buy Book                     | Bahrain eGoverment         |
	| Return Book                  | UoB Library System         |
	| Edit Book                    | UoB Library System, Moodle |
	| Add Book                     | UoB Library System, Moodle |
	| Remove Book                  | UoB Library System, Moodle |
	| Confirm Book Returns         | UoB Library System         |
	| Print                        | UoB Library System         |
	|                              |                            |
	| ***Event Module***           |                            |
	|                              |                            |
	| Add Event                    | Moodle                     |
	| Remove Event                 | Moodle                     |
	| Update Event                 | Moodle                     |
	| View Event                   | Moodle                     |
	| Sign Up for Events           | Moodle                     |
	| Cancel Event                 | Moddle                     |
	| View Candidates              | Moodle                     |
	| Calendar                     | UoB Mobile App, Moodle     |
	|                              |                            |
	| ***Student Service Module*** |                            |
	|                              |                            |
	| Reserve Locker               |                            |
	| Transport Subscription       |                            |
	| Receive Reports              | UoB Mobile App             |
	|                              |                            |
	| ***Accounting Module***      |                            |
	|                              |                            |
	| View Fines                   |                            |
	| Add Book Fees                | UoB Library System, Moodle |
	| Payment of Books             | Bahrain eGoverment         |
	| Add Parking Fees             |                            |
	|                              |                            |
	| ***Support Module***         |                            |
	|                              |                            |
	| Request Support              | SIS UoB                    |
	| Provide Support              | SIS UoB                    |
	|                              |                            |

## Starting from What You Have: start from your 305 project

The founders of the US3 system that was created for the ITSE305 course have decided it would be better to transform the UoB Students Services System into a free and open-source system. The system is new and has not fully developed and coded completely due to its being in the early stages, and due to time constraint.


Our goal of the system is to unify the multiple systems that the University of Bahrain is using into a single system this will help the users save time and effort of switching using various system that each one serves a single purpose into a one system. Also, the system will increase the performance of processing requests due to the overall cost-effective system. Moreover, the system will serve multiple users such students, library employees, system administrators, support team employees, safety and security staff. The maintenance of a single system requires less than multiple systems, it will help decrease the costs for the institution, and the effort for system maintainers.


The documentation of the US3 project is available. The file “srs.pdf” will help the open-source developers to check out the details they’re looking for and thus to make a clear decision to whether to join the development team or not. As the project is very large, the open-source developer may look for a specific part that suits his expertise and can have great ideas to add to the US3 project. For example, if a developer is experienced in developing library systems, he can request to develop the parts in US3 related to library components. The diagrams provided in the US3 documentation file are organized in such a way that it will ease the process of developing the system such as the use case diagram, class diagram, and sequence diagram. Moreover, the US3 project has followed the Attribute Driven Design (ADD) which is a method for designing software architecture. This method will always facilitate the development stages.


**Mission statement**: Allow university members to use one single powerful system with great capabilities, by combining multiple systems into a single system.


## Choose a Good Name: write how you did that 

The project name is UoB Students Services System which is shortened to US3 as an abbreviation. The ‘U’ is for UoB or University, and the ‘S3’ stands for three S’s which are “Students Services System”. The “US3” can be pronounced as “USE” as it is common in internet language to use the number 3 as letter “E”. 


  * The name of the project will give the main idea for it which is many services, and to whom which will be the students, and the institution which it will serve which is UoB or University. 

  * The name is short and easy to memorize unlike other systems which consist of many words that the users may find confusing and hard to remember. 

  * The name of the project is available to use in the U.S. as we have searched through United States Patents and Trademark Office. The projects with similar names have been removed due to cancelation. The project name can now be used, and it does not infringe other trademarks. 

  * The project can have a domain with US3.org as it is currently available to the public. Also US3Project.com is available. In twitter, we can use the username @US3Project. 


To summarize, the chosen name US3 is a very good project name and it’s short which allows users to memorize it easily. We believe that this name is unique and can be over time ne recognizable. 


## State That the Project is Free 

This system is a free open-source software system, developed under the GPL v3+ license. Feel free to participate. 

Features and Requirements List:

**Features:**

The system has several features that enable users to implement many functions easily.

  * Purchasing books and tracking orders. 
  * Multi file latex project.
  * Control and update the digital catalogue of library books by adding or removing them.
  * Search books by browsing through categories or by entering the book’s name/ISBN in the search bar, the system uses the entered information and retrieves the desired book and displays it along with its information.
  * A customized calendar provides reminders for important dates such as fines due dates for students.
  * Generate reports and view information about available books, the total number of issued books, the total number of delays and to whom.
  * view University of Bahrain events, conferences and workshops with their information which includes location, time, date, speakers, and a brief description of the event.
  * Registration of events as an attendee or member and speak with event coordinators to provide them with more details.
  * Receive certificates regarding attending university events.
  * Reservation of available lockers within college by browsing the lockers section in the system and by making a locker request.
  * The system has no sign-up page, as it will use the university database.  Users will only need to login with their email and password.
  * Online payment using an external payment provider for fines, locker reservations and purchase books.  
  * Support infrastructure for support service employees and system user base to meet and manage their issues, tickets, and guidance.
  * University’s transport subscription or renewal subscription. 

**Requirements:**

  * Frappe reference architecture
  * ERP next 

## Development Status 

The initial design of the system has been completed. However, the implementation of this project is in progress.  Developers will attempt to implement the whole project and upload it to the project’s repository. Once a function is implemented it will be uploaded to the repository until the whole project is done.
 

## Downloads 

The source code of the software should be visible to the contributors in standard formats. In our project, we use the TEX format in all our project documents.  We have already created a separate folder named “Executable Packages” which will contain all executable packages necessary to implement the system. We agreed that we must follow the standard build and installation methods. Also, there is a specific procedure we should follow when we are packaging and releasing packages. First, each executable package should have a unique version number. Second, the website of the project should have two download links: one to download the application, and one for development purposes only.

## Version Control and Bug Tracker Access 

Developers need to record changes to files over time so they can recall specific versions later. Because of that, we need to use a version control system to revert selected files back to the previous state. Developers want to compare changes over time and see the last modified files that might be causing a problem.  Change management and stability management are essential to run successful open-source software and by using VR we can handle these issues. 

We chose the Git version control system because it offers unlimited free hosting for our open-source project. Also, we keep all project sources that can be changed under the version control including designing documents, figures, requirement management plan, etc. This approach will facilitate making changes to the documents simply by submitting a commit. 

Additionally, we need to track bug reports and new feature requests. To do this we need to use a bug tracker (or issue in GitHub).   With issues we can: 

  * Track and prioritize our work using project boards. 

  * Track out-of-scope feedback from a comment in an issue or a pull request review. 

  * Help contributors open meaningful issues. 

  * Transfer open issues to other repositories. 

  * Pin important issues to make them easier to find (we can prevent duplicate issues to reduce noise). 

<!---
comment
<p align="center"><a href="https://github.com/joinlaw/US3"><img src="figures/logo.png" width="100" alt="US3"></a></p>
-->

![](figures/phase1-github-issue.png)
![](../figures/phase1-github-issue.png)


## Communications Channels
Communication is essential in software development. Especially in distributed open-source teams, communication needs to be supported by channels including mailing lists, forums, issue trackers, and chat systems. Due to that, we have searched for available message forums to adopt it in our project. After studying the available options, we agreed to use Google Groups. We can email everyone in a group with a single email address. The spam-prevention and moderation features are very useful. Also, the scalability of this tool is pretty good. 

For virtual meetings, we choose MS Teams. It is extremely user-friendly and can facilitate a work environment between remote developers from around the world. 

Address of the Communication channels:

* uob_students_system@googlegroups.com // Google groups
* فريق البرمجيات الحرة  GNU // MS teams

 
## Developer Guidelines

**Code Samples:**

Code should be optimized as possible and easy to read.

Code should be copy-paste runnable. That means a tester should be able to copy-paste the code simply and run it in an empty unit test.
 
**Code Format:**

Each line should have a single code command.

Each block of code should have a two-line margin from other code blocks.

Note: no need to do formatting manually, so use the predefined formatter.
 
**Code Scope:**
Code should not include:

* Default constructors for classes that have only the default constructor values.

* “final” keyword unless it is for constants.

* Nested for loops (at least as minimum as possible).
 
**Code-other notes:**
Variable names should be meaningful and related to each variable use.

Each group/block of code should have a brief comment explaining its use. 
 
**Developers’ Interaction:**
Developers should reach each other through email or MS Teams.
 
**Bug Report:**
Points to consider:

* Title: Keep it short and specific. Clearly summarize what the bug is.

* Summary: If title is not enough, include where, when and how the bug occurred.

* Visual proof: Screenshot or video helps the developer understand the problem faster.

* Expected vs actual result: Keep it short and specific.

* Steps to reproduce: Include the steps that created the bug.

* Environment: Include critical info like browser, operating system, screen size and zoom level.

* Console log: Identify the root of the problem.

* Source URL: To help developer spot the issue faster.

* Severity / priority: Impact level on your product / how fast it should be investigated.

* Advanced info: reporter name, assignee, due date, customer /user conversation.

Note: Do not make it harder to spot the issue by adding unhelpful information. Avoid duplicates.


## Documentation

Roles and responsibilities:


Eng. Abdulrahman Khalid was elected as the project manager and forward documentation responsibilities for Eng. Abbas Ahmed so one member holds and keeps track of changes in the project blueprint while receiving and merging others work to keep the documentation processes streamlined. Eng. Salman Khalid was selected in the committee meeting to record notes and write the weekly project report while Eng. Ahmed Adel was chosen to be the coordinator for the project while Eng. Waleed Tawfeeq will guide the software design process. Eng. Alaa Nagib will lead the effort of requirement engineering. 


Project sponsor Dr. Fawzi Albalooshi divides the project into phases of deliverables and milestones that he agreed with our team to deliver so he will review the project work from the Initiation till the project closing or termination. 


Team goals and business objectives:


System goals is to provide a secure and well-organized application that gathers all available and upcoming online services provided by the university to the students in a high performance, well-designed and easy to understand interface, the services should be available all the time every day.


How to set up the software?

1. Initialize frappe bench.

2. Use the forked US3 version with this command: 

		$ bench get-app https://gitlab.com/mr.fantastic/erpnext”. 
		
   Note that you can change the name in example with name of your site that is installed in your bench container.
	
3. Then install it to your site: “$ bench --site site.test install-app erpnext”.

4. Install US# website theme:

		$ bench get-app https://gitlab.com/mr.fantastic/bluetheme”, 
		$ bench --site site.test install-app bluetheme”.


Not doing:

A new feature will be included in the app which is the virtual tour inside the university to allow the new students to discover the university departments and other places inside it, in addition it will provide a map with detailed information about each department in the university. 

 

## Maintaining a FAQ

I cannot sign in. What do I need to do?

* Please ensure that you are using your registered email address and correct password. Note that the password is case sensitive.

* If you are registered for the first time, you will need to activate your account first. An email will be sent to the email your registered with contains a (link/code) you will need to (click/enter) in order to activate your account. If you have not received an email, please check your spam or junk mail folders.
 
What are the functionalities supported?

* Students can reserve the books they need to purchase.

* Display related data to the books like: Status, name, price, author, and other general data.

* Students can pay using credit card or benefits. (provide code through email to track order).

* Suggest the books students need through this semester.
 
How can I search for a book?

* You can search a book from “search bar” in the books list by id, title, author, subject, description, or publication date. 
 
Can I see detailed information about a book that I did not purchase yet?

*  You can find all information related to a book by clicking on its title.
 
Can I borrow books?

* You can borrow a book by clicking “rent book” button from the book page. Note that you cannot borrow a book if it is already borrowed or not available.
 
How can I buy a book?

* You can buy a book by clicking “Buy This Book” button from the book page. Note that you cannot buy a book if it is already borrowed or not available in stock.
 
How can I find the data related to my purchased books?

* In books list, you can find all your books in “purchased books” tab. You can find all information related to a book by clicking on its title.
 
How can I pay for books?

* You can pay for your services in cash or using credit card.
 
Where can I find the book suggestions for this semester?

* In books list, you can find the suggested books for you this semester in “Suggested books” tab.
 
What is the hardware required to use Uob Student Service System (US3)?

Minimum: server with 1 GB of ram and 2.4 GHz dual-core CPU

Recommended: server rack with 64 GB of ram and 3+ GHz with 4+ cores 

 
How to be a contributor?

Since our community is friendly and inclusive any patch or suggestion is welcomed and to be a contributor you can also engage in the community discussions.

 
## Developer Documentation

Developer documentations can be found at the design document and at the ERPnext/Frappe frameworks wikis as well as the project github pages and README file.


![](figures/prototype2.png)
![](../figures/prototype2.png)

![](figures/prototype3.png)
![](../figures/prototype3.png)

![](figures/prototype5.png)
![](../figures/prototype5.png)



## Hosting
 
To initialize our project, we should host it either in our own infrastructure or by using canned hosting sites and for that we planned to use github for hosting both revision control system RCS (aka version control system), bug/issue tracker, and the wiki keeping in mind that gitlab & sourceforge (sourceforge support all version control systems svn, cvs, git, and others) is another candidate for same manner.
 
Another option for setting up and host our infrastructure is to use gnu savannah (savannah.gnu.org or savannah.nongnu.org) (where they care about the freedom of the project) which include also gratis mailing lists and git email workflow and able to host your project homepage. Also tux family (tuxfamily.org) are association for free software hackers that can provide customized infrastructures for the free software projects which opens many options for the developers and that legally more secure because it hosted in france not USA which have better laws for software developers.
 
Other kinds of communication may include IRC (either in freenode network or self-hosted) and reserving necessary namespaces in popular social networks such as youtube, peertube, mastodon, twitter, reddit.
 
## Codes of Conduct
As for our community rules we selected to use the popular code convent agreement (contributor-covenant: <https://www.contributor-covenant.org/>) which is used by popular projects like the GNU/Linux kernel and in addition to that we use the GNU Kind Communications Guidelines (<https://www.gnu.org/philosophy/kind-communication.en.html>) to make sure that our environment is welcoming new hackers into our project and make sure our free software movement values stated properly and the message of our project reach wider audience in governed way not in random voluntary way so we have to control the process of communications to make sure everyone is satisfied.

## Announcing
To reach a wider audience and establish a good link with the community we arranged the announcement to be published in several popular media sources such as social networks, specialized news journals, and more importantly free software conferences. We circulated list of social media sites and groups that include the hacker news (news.ycombinator.com) site which is general light forum for hackers and startups, FSF members forum (forum.members.fsf.org) that belong to free software foundation members, Gnu announcement list (<https://lists.gnu.org/mailman/listinfo/info-gnu>) which is followed by millions of free software supporters, Slashdot, and finally an arab free software communities such as GNU/Linux arab community (<https://linuxac.org/>) and asous forum (<https://aosus.org/>).
 
Talking with free software journalists is in our plan and we will do it periodically and we have selected several magazines and news sites including phoronix (<https://www.phoronix.com/scan.php?page=home>), lwn [GNU/Linux Weekly News] (<https://lwn.net/>), and plant GNU (<https://planet.gnu.org/>) rss feed aggregator which we will planned to add our blog at.
 
Most important step in announcing our project will be participating if free software conferences such as Chaos Computer Club (CCC) conference (media.ccc.de), fosdem conference (<https://fosdem.org/2021/>), guadec conference (<https://events.gnome.org/event/9/>), libreplant groups & community (<https://libreplanet.org/wiki/Main_Page>), FISL conference (brazil), OSCON conference, and any GNU/Linux users' groups.
