/*
PROJECT
SECTION : 01
STUDENT 1:
       Name : Gehad Elsayed 
       ID : 20176281
STUDENT 2 : 
       Name : 
       ID : 
*/
Import java.util.ArrayList ;
Public class HYAT
{
private String cpr;              //ID number of the student
private String Fname;       // first name of the student
private String Iname;        //last name of the student
private String gender;      // gender of the student
private String email;        // email of the student
private String bloodType;

// constructor to initialize the data members depending on the parameters that are passed to the method
public Patient (String cpr, String fame, String lname, String gender, String email, String bloodType) 
{
this. cpr = cpr;
Fame = fname;
Lname = lname
this. gender = gender;
this. email = email:
this. bloodType= bloodType;
}
// default constructor to initialize the data members to default values 
Public Patient () { 
cpr=“”;
Fname=“”;
Lname=“”;
gender=“”;
email=“”;
bloodType=“”
}
